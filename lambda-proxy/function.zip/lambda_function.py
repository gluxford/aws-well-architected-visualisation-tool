import json
import boto3
import os
import logging
import ipaddress
import traceback
import botocore

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Allowed IP address
ALLOWED_IP = "159.196.13.45/32"

def is_ip_allowed(source_ip):
    """Check if the source IP is in the allowed range"""
    try:
        allowed_network = ipaddress.ip_network(ALLOWED_IP)
        client_ip = ipaddress.ip_address(source_ip)
        return client_ip in allowed_network
    except Exception as e:
        logger.error(f"Error checking IP address: {str(e)}")
        return False

def lambda_handler(event, context):
    # Set CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,POST'
    }
    
    # Log the entire event for debugging
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Handle preflight OPTIONS request
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({})
        }
    
    try:
        # Get client IP address
        source_ip = event.get('requestContext', {}).get('identity', {}).get('sourceIp', '')
        logger.info(f"Request from IP: {source_ip}")
        
        # Temporarily disable IP restriction for debugging
        # if not is_ip_allowed(source_ip):
        #     logger.warning(f"Access denied for IP: {source_ip}")
        #     return {
        #         'statusCode': 403,
        #         'headers': headers,
        #         'body': json.dumps({
        #             'error': 'Access denied. Your IP address is not authorized.'
        #         })
        #     }
        
        # Parse request body
        body = json.loads(event['body'])
        operation = body.get('operation')
        params = body.get('params', {})
        
        logger.info(f"Received request for operation: {operation}")
        logger.info(f"Parameters: {json.dumps(params)}")
        
        # Map operation names to actual SDK method names
        operation_mapping = {
            'list_workloads': 'list_workloads',
            'get_workload': 'get_workload',
            'list_lens_reviews': 'list_lens_reviews',
            'get_lens_review': 'get_lens_review',
            'list_answers': 'list_answers'
        }
        
        # Get the actual SDK method name
        sdk_operation = operation_mapping.get(operation, operation)
        
        # Log boto3 and botocore versions
        logger.info(f"boto3 version: {boto3.__version__}")
        logger.info(f"botocore version: {botocore.__version__}")
        
        # Create WellArchitected client using the Lambda's role
        # Explicitly set the region to match where your workloads are
        region = os.environ.get('AWS_REGION', 'ap-southeast-2')
        logger.info(f"Using region: {region}")
        
        # Create the client without any credentials - use Lambda role
        wa_client = boto3.client('wellarchitected', region_name=region)
        
        # Special handling for get_workload which needs WorkloadId
        if sdk_operation == 'get_workload' and 'WorkloadId' in params:
            # Check if WorkloadId is a full ARN and extract the ID if needed
            workload_id = params['WorkloadId']
            if workload_id.startswith('arn:aws:wellarchitected:'):
                # Extract the ID from the ARN
                workload_id = workload_id.split('/')[-1]
                params['WorkloadId'] = workload_id
                logger.info(f"Extracted WorkloadId from ARN: {workload_id}")
        
        # Log the AWS identity being used
        try:
            sts_client = boto3.client('sts')
            identity = sts_client.get_caller_identity()
            logger.info(f"AWS Identity: {json.dumps(identity, default=str)}")
        except Exception as e:
            logger.error(f"Error getting identity: {str(e)}")
        
        # Execute the requested operation
        logger.info(f"Executing operation: {sdk_operation} with params: {json.dumps(params)}")
        response = getattr(wa_client, sdk_operation)(**params)
        
        logger.info(f"Operation {sdk_operation} completed successfully")
        logger.info(f"Response: {json.dumps(response, default=str)}")
        
        # Return successful response
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(response, default=str)
        }
    except Exception as e:
        logger.error(f"Error executing operation: {str(e)}")
        logger.error(traceback.format_exc())
        # Return error response
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': str(e)
            })
        }
